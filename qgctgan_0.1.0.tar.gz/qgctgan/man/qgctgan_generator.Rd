\name{qgctgan_generator}
\alias{qgctgan_generator}
\alias{print.qgctgan_generator}
\title{Construct a generator object}
\usage{
qgctgan_generator(fit, sample, name = "custom")

\method{print}{qgctgan_generator}(x, ...)
}
\arguments{
\item{fit}{A function of a numeric matrix returning a fitted model.}

\item{sample}{A function of \code{(model, n)} returning an \code{n} x d numeric
matrix of synthetic samples.}

\item{name}{A short label used when printing.}

\item{x}{A \code{qgctgan_generator} object (for the print method).}

\item{...}{Further arguments (ignored by the print method).}
}
\value{
An object of class \code{"qgctgan_generator"}.
}
\description{
A generator object carries two functions, \code{fit(X)} and
\code{sample(model, n)}, that the two-stage quality filter builds on. This lets
the pipeline operate on top of any generator: the pure-R Gaussian default, an
external CTGAN through \pkg{reticulate}, or a user-supplied model.
}
\examples{
gen <- qgctgan_generator(
  fit = function(X) list(mu = colMeans(X)),
  sample = function(model, n)
    matrix(model$mu, n, length(model$mu), byrow = TRUE),
  name = "mean-only")
gen
}
\seealso{\code{\link{generator_gaussian}}, \code{\link{generator_ctgan}}}
