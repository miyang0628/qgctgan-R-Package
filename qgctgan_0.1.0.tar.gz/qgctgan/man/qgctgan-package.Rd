\name{qgctgan-package}
\alias{qgctgan-package}
\docType{package}
\title{qgctgan: Quality-Aware Cluster-Conditioned Oversampling}
\description{
A generator-agnostic framework for oversampling imbalanced tabular data. The
minority class is partitioned into sub-clusters with a Gaussian mixture model,
synthetic candidates are drawn per sub-cluster from a pluggable generator, and
the candidates pass a two-stage quality filter (composite quality score with an
adaptive per-cluster rejection quantile, followed by a greedy maximum mean
discrepancy selection).
}
\details{
The main entry point is \code{\link{qgctgan}}. The unfiltered baseline is
\code{\link{gctgan}}. Generators are built with
\code{\link{qgctgan_generator}}; \code{\link{generator_gaussian}} is the pure-R
default and \code{\link{generator_ctgan}} is an optional CTGAN backend.
}
\references{
Yang, M. (2026). Quality-Aware Cluster-Conditioned Oversampling via
Intra-Cluster Synthetic Sample Filtering. \emph{Applied Soft Computing}.
}
\author{
Munil Yang
}
\keyword{package}
