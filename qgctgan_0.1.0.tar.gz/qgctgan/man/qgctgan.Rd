\name{qgctgan}
\alias{qgctgan}
\title{Quality-aware cluster-conditioned oversampling}
\usage{
qgctgan(x, y, positive = NULL, generator = generator_gaussian(),
  target_ratio = 0.5, k_range = 2:10,
  alpha_mode = c("adaptive", "fixed"), alpha = 0.2,
  alpha_min = 0.1, alpha_max = 0.3, mmd_stage = TRUE, filter = TRUE,
  candidate_multiplier = 5, max_multiplier = 50, safety_factor = 1.5,
  weights = c(1/3, 1/3, 1/3), n_neighbors = 5L, seed = NULL,
  verbose = FALSE)
}
\arguments{
\item{x}{A numeric matrix or data frame of (preferably standardised) numeric
features, one observation per row.}

\item{y}{A vector of binary class labels, one per row of \code{x}.}

\item{positive}{The label of the minority/positive class. If \code{NULL}
(default), the least frequent label is used.}

\item{generator}{A \code{\link{qgctgan_generator}}. Defaults to the pure-R
\code{\link{generator_gaussian}}; use \code{\link{generator_ctgan}} to
reproduce the GAN-based generation of the reference study.}

\item{target_ratio}{Desired minority fraction after oversampling.}

\item{k_range}{Integer vector of candidate GMM component counts (BIC-selected).}

\item{alpha_mode}{\code{"adaptive"} (per-cluster, from GMM log-likelihood) or
\code{"fixed"}.}

\item{alpha}{Rejection quantile used when \code{alpha_mode = "fixed"}.}

\item{alpha_min, alpha_max}{Bounds for the adaptive rejection quantile.}

\item{mmd_stage}{Logical; run the Stage-2 MMD selection.}

\item{filter}{Logical; if \code{FALSE}, the two-stage filter is skipped and
synthetic samples are drawn uniformly at random from the candidate pool
(the unfiltered "G-CTGAN" baseline). See also \code{\link{gctgan}}.}

\item{candidate_multiplier, max_multiplier, safety_factor}{Control how many
candidates are generated per minority sample.}

\item{weights}{Length-3 weights for the density, separability and
local-outlier components of \eqn{Q(x)}.}

\item{n_neighbors}{Neighbour count for the local-outlier component.}

\item{seed}{Optional integer seed for reproducibility.}

\item{verbose}{Logical; print progress.}
}
\value{
An object of class \code{"qgctgan"}: a list with the rebalanced feature matrix
\code{x}, labels \code{y}, the \code{synthetic} samples that were added, and an
\code{info} list of diagnostics.
}
\description{
Oversamples the minority class of an imbalanced binary problem. The minority
class is partitioned into sub-clusters with a Gaussian mixture model; a
generator is fitted per sub-cluster and used to draw synthetic candidates; the
candidates then pass the two-stage quality filter (Stage 1: composite quality
score \eqn{Q(x)} with an adaptive per-cluster rejection quantile; Stage 2:
greedy MMD selection) before the retained samples are added to the training
set.
}
\examples{
set.seed(1)
n <- 200
x <- rbind(matrix(rnorm(2 * n), n, 2),
           matrix(rnorm(2 * 20, mean = 2), 20, 2))
y <- c(rep(0L, n), rep(1L, 20))
res <- qgctgan(x, y, seed = 1)
table(res$y)
}
\references{
Yang, M. (2026). Quality-Aware Cluster-Conditioned Oversampling via
Intra-Cluster Synthetic Sample Filtering. \emph{Applied Soft Computing}.
}
\seealso{\code{\link{gctgan}}, \code{\link{generator_gaussian}},
\code{\link{generator_ctgan}}}
