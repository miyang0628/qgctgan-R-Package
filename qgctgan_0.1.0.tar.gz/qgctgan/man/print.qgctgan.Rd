\name{print.qgctgan}
\alias{print.qgctgan}
\title{Print a qgctgan oversampling result}
\usage{
\method{print}{qgctgan}(x, ...)
}
\arguments{
\item{x}{An object of class \code{"qgctgan"}.}

\item{...}{Ignored.}
}
\value{
\code{x}, invisibly.
}
\description{
Prints a short summary of a rebalanced data set produced by
\code{\link{qgctgan}}.
}
