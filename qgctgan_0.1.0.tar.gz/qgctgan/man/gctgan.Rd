\name{gctgan}
\alias{gctgan}
\title{Unfiltered cluster-conditioned oversampling (G-CTGAN baseline)}
\usage{
gctgan(x, y, positive = NULL, generator = generator_gaussian(),
  target_ratio = 0.5, k_range = 2:10, candidate_multiplier = 5,
  max_multiplier = 50, safety_factor = 1.5, seed = NULL,
  verbose = FALSE)
}
\arguments{
\item{x}{A numeric matrix or data frame of numeric features, one row per
observation.}

\item{y}{A vector of binary class labels.}

\item{positive}{The label of the minority/positive class (default: least
frequent).}

\item{generator}{A \code{\link{qgctgan_generator}} (default
\code{\link{generator_gaussian}}).}

\item{target_ratio}{Desired minority fraction after oversampling.}

\item{k_range}{Integer vector of candidate GMM component counts.}

\item{candidate_multiplier, max_multiplier, safety_factor}{Control how many
candidates are generated per minority sample.}

\item{seed}{Optional integer seed.}

\item{verbose}{Logical; print progress.}
}
\value{
An object of class \code{"qgctgan"}.
}
\description{
Convenience wrapper for \code{qgctgan(..., filter = FALSE)}: the same
generative base (GMM + per-cluster generator + candidate pool) with the
two-stage quality filter removed, so synthetic samples are drawn uniformly at
random from the candidate pool. Used to isolate the contribution of the filter.
}
\seealso{\code{\link{qgctgan}}}
