\name{generator_gaussian}
\alias{generator_gaussian}
\title{Pure-R Gaussian generator}
\usage{
generator_gaussian(reg = 1e-6)
}
\arguments{
\item{reg}{Ridge added to the diagonal of each covariance for stability.}
}
\value{
A \code{\link{qgctgan_generator}}.
}
\description{
Fits a (regularised) multivariate normal to each cluster and samples from it.
This is the default generator: it has no external dependencies, so the whole
pipeline runs out of the box. It is a baseline generator, not a replacement for
a tabular GAN; for higher-fidelity generation use \code{\link{generator_ctgan}}.
}
\examples{
set.seed(1)
X <- matrix(rnorm(40), 20, 2)
gen <- generator_gaussian()
m <- gen$fit(X)
dim(gen$sample(m, 5))
}
\seealso{\code{\link{generator_ctgan}}, \code{\link{qgctgan_generator}}}
