\name{generator_ctgan}
\alias{generator_ctgan}
\title{CTGAN generator (optional, via reticulate)}
\usage{
generator_ctgan(epochs = 100L, verbose = FALSE, ...)
}
\arguments{
\item{epochs}{Number of CTGAN training epochs.}

\item{verbose}{Passed to CTGAN.}

\item{...}{Further arguments forwarded to \code{ctgan.CTGAN()}.}
}
\value{
A \code{\link{qgctgan_generator}}.
}
\description{
Wraps the Python \pkg{ctgan} package so that a conditional tabular GAN is
trained per cluster, reproducing the generator used in the reference study.
Requires \pkg{reticulate} and a Python environment in which \code{ctgan} (and
its \code{torch} backend) is installed; it is not needed for the rest of the
package to work.
}
\examples{
\dontrun{
  gen <- generator_ctgan(epochs = 100)
  res <- qgctgan(X, y, generator = gen)
}
}
\seealso{\code{\link{generator_gaussian}}, \code{\link{qgctgan_generator}}}
