## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(qgctgan)

set.seed(1)
n_maj <- 300
X_maj <- matrix(rnorm(2 * n_maj), n_maj, 2)
X_min <- rbind(matrix(rnorm(2 * 15, mean =  2.5), 15, 2),
               matrix(rnorm(2 * 15, mean = -2.5), 15, 2))
x <- rbind(X_maj, X_min)
y <- c(rep(0L, n_maj), rep(1L, 30))

res <- qgctgan(x, y, seed = 1)
res
table(res$y)

## -----------------------------------------------------------------------------
base <- gctgan(x, y, seed = 1)
base$info$n_synthetic

## ----eval = FALSE-------------------------------------------------------------
# res <- qgctgan(x, y, generator = generator_ctgan(epochs = 100), seed = 1)

## -----------------------------------------------------------------------------
gen <- qgctgan_generator(
  fit = function(X) list(mu = colMeans(X),
                         L  = chol(cov(X) + diag(1e-6, ncol(X)))),
  sample = function(m, n)
    sweep(matrix(rnorm(n * length(m$mu)), n) %*% m$L, 2, m$mu, "+"),
  name = "mvnorm")

