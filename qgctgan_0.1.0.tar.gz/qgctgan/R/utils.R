## Small numeric helpers used across the package.

#' Moore-Penrose pseudo-inverse via SVD
#' @param m A numeric matrix.
#' @param tol Relative singular-value tolerance.
#' @return The pseudo-inverse of \code{m}.
#' @keywords internal
.ginv <- function(m, tol = sqrt(.Machine$double.eps)) {
  s <- svd(m)
  pos <- s$d > max(tol * s$d[1], 0)
  if (!any(pos)) return(matrix(0, nrow = ncol(m), ncol = nrow(m)))
  s$v[, pos, drop = FALSE] %*%
    ((1 / s$d[pos]) * t(s$u[, pos, drop = FALSE]))
}

#' Row-wise minimum Euclidean distance from points to a set of centres
#' @param X Numeric matrix (points in rows).
#' @param C Numeric matrix (centres in rows).
#' @return A numeric vector of length \code{nrow(X)}.
#' @keywords internal
.min_dist_to <- function(X, C) {
  X <- as.matrix(X); C <- as.matrix(C)
  xx <- rowSums(X^2)
  cc <- rowSums(C^2)
  d2 <- outer(xx, cc, "+") - 2 * (X %*% t(C))
  d2[d2 < 0] <- 0
  sqrt(apply(d2, 1, min))
}

#' Min-max normalise a vector to [0, 1]
#' @param v A numeric vector.
#' @keywords internal
.minmax <- function(v) {
  lo <- min(v); hi <- max(v)
  (v - lo) / (hi - lo + 1e-8)
}

#' Draw from a multivariate normal using an eigen decomposition (base R only)
#' @param n Number of samples.
#' @param mu Mean vector.
#' @param Sigma Covariance matrix.
#' @keywords internal
.rmvnorm <- function(n, mu, Sigma) {
  d <- length(mu)
  e <- eigen(Sigma, symmetric = TRUE)
  L <- e$vectors %*% diag(sqrt(pmax(e$values, 0)), d)
  Z <- matrix(stats::rnorm(n * d), nrow = n, ncol = d)
  sweep(Z %*% t(L), 2, mu, "+")
}
