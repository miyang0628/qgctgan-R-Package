## Stage-1 composite quality score Q(x) and its three components.
## Ported from qgctgan_core.py (s_density, s_sep, s_lof, quality_score).

#' Intra-cluster density score
#'
#' \eqn{S_{density}(x) = \exp(-D_M(x; \mu_c, \Sigma_c))}, where \eqn{D_M} is the
#' Mahalanobis distance to the candidate's own GMM component. Higher is better
#' (closer to the cluster centre).
#'
#' @param X_syn Numeric matrix of candidate samples (rows).
#' @param mu_c Numeric vector: component mean.
#' @param sigma_c Numeric matrix: component covariance.
#' @return A numeric vector of length \code{nrow(X_syn)}.
#' @keywords internal
s_density <- function(X_syn, mu_c, sigma_c) {
  X_syn <- as.matrix(X_syn)
  out <- tryCatch({
    sinv <- .ginv(sigma_c)
    diff <- sweep(X_syn, 2, mu_c, "-")
    maha <- sqrt(pmax(rowSums((diff %*% sinv) * diff), 0))
    exp(-maha)
  }, error = function(e) rep(0.5, nrow(X_syn)))
  out
}

#' Class-separability score
#'
#' \eqn{S_{sep}(x) = d_{maj} / (d_{maj} + d_{min} + \epsilon)}, where
#' \eqn{d_{maj}} and \eqn{d_{min}} are the distances to the nearest majority and
#' minority centre. Higher means the candidate sits further from the majority
#' class relative to the minority class.
#'
#' @param X_syn Numeric matrix of candidate samples.
#' @param mu_minority_all Numeric matrix of minority component means (rows).
#' @param mu_majority_clusters Numeric matrix of majority centre(s) (rows).
#' @param eps Small constant for numerical stability.
#' @return A numeric vector.
#' @keywords internal
s_sep <- function(X_syn, mu_minority_all, mu_majority_clusters, eps = 1e-8) {
  d_maj <- .min_dist_to(X_syn, mu_majority_clusters)
  d_min <- .min_dist_to(X_syn, mu_minority_all)
  d_maj / (d_maj + d_min + eps)
}

#' Local-outlier score
#'
#' \eqn{S_{lof}(x) = 1 / \mathrm{LOF}(x)}, with the local outlier factor computed
#' within the candidate's own cluster (real cluster points plus candidates).
#' Higher means less of an outlier.
#'
#' @param X_syn Numeric matrix of candidate samples.
#' @param X_cluster_real Numeric matrix of real points in the same cluster.
#' @param n_neighbors Number of neighbours for the LOF computation.
#' @return A numeric vector.
#' @keywords internal
s_lof <- function(X_syn, X_cluster_real, n_neighbors = 5L) {
  X_syn <- as.matrix(X_syn)
  X_cluster_real <- as.matrix(X_cluster_real)
  n_real <- nrow(X_cluster_real)
  n_nb <- min(n_neighbors, n_real - 1L)
  if (n_nb < 1L) return(rep(0.5, nrow(X_syn)))
  out <- tryCatch({
    X_combined <- rbind(X_cluster_real, X_syn)
    lof_vals <- dbscan::lof(X_combined, minPts = n_nb)
    lof_syn <- lof_vals[(n_real + 1L):nrow(X_combined)]
    1 / pmax(lof_vals_finite(lof_syn), 1e-8)
  }, error = function(e) rep(0.5, nrow(X_syn)))
  out
}

## LOF can return Inf for exact duplicates; treat those as strong outliers.
lof_vals_finite <- function(v) {
  v[!is.finite(v)] <- max(v[is.finite(v)], 1, na.rm = TRUE)
  v
}

#' Composite Stage-1 quality score
#'
#' \eqn{Q(x) = w_1 \hat S_{density} + w_2 \hat S_{sep} + w_3 \hat S_{lof}}, with
#' each component min-max normalised to [0, 1] over the candidate set.
#'
#' @param X_syn Numeric matrix of candidate samples.
#' @param mu_c,sigma_c Mean and covariance of the candidate's GMM component.
#' @param mu_minority_all Numeric matrix of minority component means.
#' @param mu_majority_clusters Numeric matrix of majority centre(s).
#' @param X_cluster_real Numeric matrix of real cluster points.
#' @param w Length-3 numeric vector of component weights (summing to 1).
#' @return A numeric vector of quality scores, one per candidate.
#' @keywords internal
quality_score <- function(X_syn, mu_c, sigma_c, mu_minority_all,
                          mu_majority_clusters, X_cluster_real,
                          w = c(1/3, 1/3, 1/3)) {
  sd_ <- s_density(X_syn, mu_c, sigma_c)
  ss_ <- s_sep(X_syn, mu_minority_all, mu_majority_clusters)
  sl_ <- s_lof(X_syn, X_cluster_real)
  w[1] * .minmax(sd_) + w[2] * .minmax(ss_) + w[3] * .minmax(sl_)
}
