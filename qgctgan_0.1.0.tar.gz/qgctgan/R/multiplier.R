## Candidate-generation multiplier sizing.
## Ported from qgctgan_core.py (compute_required_multiplier).

#' Required candidate multiplier to reach a target minority ratio
#'
#' Determines how many synthetic samples are needed to bring the minority class
#' to \code{target_ratio} of the data set, and the per-minority candidate
#' multiplier (clipped to \code{[base_multiplier, max_multiplier]}) to generate
#' enough candidates with a safety margin.
#'
#' @param n_min,n_maj Minority and majority sample counts.
#' @param target_ratio Desired minority fraction after oversampling.
#' @param base_multiplier,max_multiplier Lower/upper clip on the multiplier.
#' @param safety_factor Oversupply factor applied to the needed count.
#' @return A list with \code{multiplier}, \code{n_syn_needed} and
#'   \code{achievable_ratio} (the best minority ratio reachable at the cap).
#' @keywords internal
compute_required_multiplier <- function(n_min, n_maj, target_ratio = 0.5,
                                        base_multiplier = 5, safety_factor = 1.5,
                                        max_multiplier = 50) {
  n_syn_needed <- max(round((target_ratio * (n_maj + n_min) - n_min) /
                              (1 - target_ratio)), 0)
  if (n_min == 0) {
    return(list(multiplier = base_multiplier, n_syn_needed = n_syn_needed,
                achievable_ratio = target_ratio))
  }
  required <- (n_syn_needed * safety_factor) / n_min
  multiplier <- min(max(required, base_multiplier), max_multiplier)
  max_possible <- multiplier * n_min
  achievable <- (n_min + max_possible) / (n_maj + n_min + max_possible)
  list(multiplier = multiplier, n_syn_needed = as.integer(n_syn_needed),
       achievable_ratio = round(achievable, 4))
}
