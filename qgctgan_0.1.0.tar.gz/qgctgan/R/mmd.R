## Maximum Mean Discrepancy (MMD) utilities
## Ported from qgctgan_core.py (rbf_kernel, median_bandwidth, mmd_squared,
## mmd_contribution) with identical numerics.

#' Gaussian (RBF) kernel matrix
#'
#' Computes the radial basis function kernel \eqn{k(x, y) = \exp(-\gamma \lVert x
#' - y \rVert^2)} between every pair of rows of \code{X} and \code{Y}.
#'
#' @param X A numeric matrix with one observation per row.
#' @param Y A numeric matrix with the same number of columns as \code{X}.
#' @param gamma Kernel bandwidth parameter. If \code{NULL} (default), uses
#'   \code{1 / ncol(X)}.
#'
#' @return A numeric matrix of dimension \code{nrow(X)} by \code{nrow(Y)}.
#' @keywords internal
rbf_kernel <- function(X, Y, gamma = NULL) {
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  if (is.null(gamma)) gamma <- 1 / ncol(X)
  xx <- rowSums(X^2)
  yy <- rowSums(Y^2)
  d2 <- outer(xx, yy, "+") - 2 * (X %*% t(Y))
  d2[d2 < 0] <- 0
  exp(-gamma * d2)
}

#' Median-heuristic kernel bandwidth
#'
#' Computes \eqn{\gamma = 1 / (2\,\mathrm{median}\,\lVert z_i - z_j \rVert^2)}
#' over the pooled sample, the standard median heuristic for RBF kernels.
#'
#' @param X,Y Numeric matrices of observations (rows).
#' @param sample_size Maximum number of rows drawn from each of \code{X} and
#'   \code{Y} before computing pairwise distances (for speed). Subsampling is
#'   only performed when a matrix has more rows than \code{sample_size}.
#'
#' @return A single numeric bandwidth \code{gamma}.
#' @keywords internal
median_bandwidth <- function(X, Y, sample_size = 500L) {
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  if (nrow(X) > sample_size) X <- X[sample.int(nrow(X), sample_size), , drop = FALSE]
  if (nrow(Y) > sample_size) Y <- Y[sample.int(nrow(Y), sample_size), , drop = FALSE]
  Z <- rbind(X, Y)
  d2 <- as.vector(stats::dist(Z))^2
  d2 <- d2[d2 > 0]
  if (length(d2) == 0) return(1)
  1 / (2 * stats::median(d2) + 1e-8)
}

#' Biased MMD^2 estimate between two samples
#'
#' @param X,Y Numeric matrices of observations (rows).
#' @param min_samples Minimum rows required in each sample; otherwise
#'   \code{NA} is returned.
#'
#' @return A single numeric \eqn{\mathrm{MMD}^2} value, or \code{NA}.
#' @keywords internal
mmd_squared <- function(X, Y, min_samples = 10L) {
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  if (nrow(X) < min_samples || nrow(Y) < min_samples) return(NA_real_)
  gamma <- median_bandwidth(X, Y)
  mean(rbf_kernel(X, X, gamma)) -
    2 * mean(rbf_kernel(X, Y, gamma)) +
    mean(rbf_kernel(Y, Y, gamma))
}

#' Approximate MMD^2 contribution of a single candidate
#'
#' Lower values indicate that adding \code{x_new} moves the synthetic set closer
#' to the real reference distribution.
#'
#' @param x_new A numeric vector (one candidate).
#' @param X_ref Numeric matrix of real reference observations.
#' @param X_pool Numeric matrix of the current synthetic pool (may have 0 rows).
#' @param gamma Kernel bandwidth.
#'
#' @return A single numeric score.
#' @keywords internal
mmd_contribution <- function(x_new, X_ref, X_pool, gamma) {
  x_new <- matrix(x_new, nrow = 1)
  k_xref <- mean(rbf_kernel(x_new, X_ref, gamma))
  k_xsyn <- if (nrow(as.matrix(X_pool)) > 0) mean(rbf_kernel(x_new, X_pool, gamma)) else 0
  -2 * k_xref + k_xsyn
}
