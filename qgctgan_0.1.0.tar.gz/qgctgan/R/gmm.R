## Minority-class Gaussian mixture modelling.
## Uses mclust for BIC-based selection of the number of components with full
## ("VVV") covariance, mirroring the scikit-learn GaussianMixture configuration
## of the reference implementation.

## Log-density of a multivariate normal (one or more points).
.dmvnorm_log <- function(X, mu, sigma) {
  X <- as.matrix(X)
  d <- ncol(X)
  sigma <- sigma + diag(1e-6, d)
  ch <- chol(sigma)
  logdet <- 2 * sum(log(diag(ch)))
  z <- backsolve(ch, t(sweep(X, 2, mu, "-")), transpose = TRUE)
  q <- colSums(z^2)
  -0.5 * (d * log(2 * pi) + logdet + q)
}

#' Fit a minority-class Gaussian mixture with BIC component selection
#'
#' @param X_min Numeric matrix of minority observations (rows).
#' @param k_range Integer vector of candidate component counts.
#' @param seed Optional integer seed for reproducible fitting.
#' @return A list with elements \code{best_k}, \code{means} (\code{best_k} x d),
#'   \code{covariances} (d x d x \code{best_k} array), \code{labels} (0-based
#'   integer cluster assignments) and \code{loglik_point} (per-observation
#'   mixture log-likelihood).
#' @keywords internal
fit_gmm_select <- function(X_min, k_range = 2:10, seed = NULL) {
  X_min <- as.matrix(X_min)
  n <- nrow(X_min); d <- ncol(X_min)
  if (!is.null(seed)) set.seed(seed)

  feasible <- k_range[k_range * 2 <= n]
  mod <- NULL
  if (length(feasible) > 0) {
    mod <- tryCatch(
      mclust::densityMclust(X_min, G = feasible, modelNames = "VVV",
                            plot = FALSE, verbose = FALSE),
      error = function(e) NULL)
  }

  if (is.null(mod)) {
    ## Fallback: single Gaussian (degenerate minority cluster).
    mu <- colMeans(X_min)
    sigma <- if (n >= 2) stats::cov(X_min) else diag(1, d)
    sigma[!is.finite(sigma)] <- 0
    means <- matrix(mu, nrow = 1)
    covariances <- array(sigma, dim = c(d, d, 1))
    return(list(best_k = 1L,
                means = means,
                covariances = covariances,
                labels = rep(0L, n),
                loglik_point = .dmvnorm_log(X_min, mu, sigma)))
  }

  best_k <- mod$G
  means <- t(mod$parameters$mean)                      # best_k x d
  sig <- mod$parameters$variance$sigma                 # d x d x best_k
  if (length(dim(sig)) == 2) sig <- array(sig, dim = c(d, d, 1))
  labels <- as.integer(mod$classification) - 1L
  loglik_point <- log(mod$density)                     # per-point mixture density
  loglik_point[!is.finite(loglik_point)] <- min(loglik_point[is.finite(loglik_point)], na.rm = TRUE)

  list(best_k = as.integer(best_k),
       means = means,
       covariances = sig,
       labels = labels,
       loglik_point = loglik_point)
}
