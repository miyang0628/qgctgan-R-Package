## Adaptive per-cluster rejection quantile.
## Ported from qgctgan_core.py (compute_adaptive_alpha).

#' Adaptive per-cluster rejection quantile
#'
#' Computes \eqn{\alpha_c = \alpha_{max} - (\alpha_{max} - \alpha_{min})\,
#' \tilde\ell_c}, where \eqn{\tilde\ell_c} is the min-max normalised mean GMM
#' log-likelihood of cluster \eqn{c}. Stable (high log-likelihood) clusters get a
#' small \eqn{\alpha_c} (less filtering); unstable clusters get a large
#' \eqn{\alpha_c} (more filtering).
#'
#' @param loglik_point Numeric vector: per-point mixture log-likelihood for each
#'   minority observation (same order as \code{labels}).
#' @param labels Integer vector of cluster assignments in \code{0:(best_k-1)}.
#' @param best_k Number of clusters.
#' @param alpha_min,alpha_max Lower/upper bounds on the rejection quantile.
#' @return A numeric vector of length \code{best_k}.
#' @keywords internal
compute_adaptive_alpha <- function(loglik_point, labels, best_k,
                                   alpha_min = 0.1, alpha_max = 0.3) {
  log_liks <- vapply(seq_len(best_k) - 1L, function(c) {
    idx <- labels == c
    if (sum(idx) >= 2L) mean(loglik_point[idx]) else -Inf
  }, numeric(1))

  valid <- log_liks[is.finite(log_liks)]
  if (length(valid) == 0L) {
    return(rep((alpha_min + alpha_max) / 2, best_k))
  }
  log_liks[!is.finite(log_liks)] <- min(valid)
  ll_min <- min(log_liks); ll_max <- max(log_liks)
  ll_norm <- (log_liks - ll_min) / (ll_max - ll_min + 1e-8)
  pmin(pmax(alpha_max - (alpha_max - alpha_min) * ll_norm, alpha_min), alpha_max)
}
