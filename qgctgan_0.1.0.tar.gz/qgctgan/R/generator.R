## Pluggable synthetic-sample generators.
##
## A generator is a small object carrying two functions:
##   fit(X)          -> a fitted model for a single cluster's real points
##   sample(model,n) -> an n x ncol(X) numeric matrix of synthetic candidates
## This indirection lets the two-stage quality filter operate on top of any
## generator: the pure-R Gaussian default below, an external CTGAN through
## 'reticulate', or a user-supplied model.

#' Construct a generator object
#'
#' @param fit A function of a numeric matrix returning a fitted model.
#' @param sample A function of \code{(model, n)} returning an \code{n} x d
#'   numeric matrix of synthetic samples.
#' @param name A short label used when printing.
#' @return An object of class \code{"qgctgan_generator"}.
#' @export
#' @examples
#' gen <- qgctgan_generator(
#'   fit = function(X) list(mu = colMeans(X)),
#'   sample = function(model, n)
#'     matrix(model$mu, n, length(model$mu), byrow = TRUE),
#'   name = "mean-only")
#' gen
qgctgan_generator <- function(fit, sample, name = "custom") {
  stopifnot(is.function(fit), is.function(sample))
  structure(list(fit = fit, sample = sample, name = name),
            class = "qgctgan_generator")
}

#' @export
print.qgctgan_generator <- function(x, ...) {
  cat("<qgctgan generator:", x$name, ">\n")
  invisible(x)
}

#' Pure-R Gaussian generator
#'
#' Fits a (regularised) multivariate normal to each cluster and samples from it.
#' This is the default generator: it has no external dependencies, so the whole
#' pipeline runs out of the box. It is a baseline generator, not a replacement
#' for a tabular GAN; for higher-fidelity generation use
#' \code{\link{generator_ctgan}}.
#'
#' @param reg Ridge added to the diagonal of each covariance for stability.
#' @return A \code{qgctgan_generator}.
#' @export
#' @examples
#' set.seed(1)
#' X <- matrix(rnorm(40), 20, 2)
#' gen <- generator_gaussian()
#' m <- gen$fit(X)
#' dim(gen$sample(m, 5))
generator_gaussian <- function(reg = 1e-6) {
  qgctgan_generator(
    name = "gaussian",
    fit = function(X) {
      X <- as.matrix(X); d <- ncol(X)
      mu <- colMeans(X)
      Sigma <- if (nrow(X) >= 2) stats::cov(X) else matrix(0, d, d)
      Sigma[!is.finite(Sigma)] <- 0
      Sigma <- Sigma + diag(reg, d)
      list(mu = mu, Sigma = Sigma, d = d)
    },
    sample = function(model, n) {
      if (n <= 0) return(matrix(numeric(0), 0, model$d))
      .rmvnorm(n, model$mu, model$Sigma)
    })
}

#' CTGAN generator (optional, via reticulate)
#'
#' Wraps the Python \pkg{ctgan} package so that a conditional tabular GAN is
#' trained per cluster, reproducing the generator used in the reference study.
#' Requires \pkg{reticulate} and a Python environment in which \code{ctgan}
#' (and its \code{torch} backend) is installed; it is not needed for the rest of
#' the package to work.
#'
#' @param epochs Number of CTGAN training epochs.
#' @param verbose Passed to CTGAN.
#' @param ... Further arguments forwarded to \code{ctgan.CTGAN()}.
#' @return A \code{qgctgan_generator}.
#' @export
#' @examples
#' \dontrun{
#'   gen <- generator_ctgan(epochs = 100)
#'   res <- qgctgan(X, y, generator = gen)
#' }
generator_ctgan <- function(epochs = 100L, verbose = FALSE, ...) {
  if (!requireNamespace("reticulate", quietly = TRUE)) {
    stop("generator_ctgan() requires the 'reticulate' package.", call. = FALSE)
  }
  extra <- list(...)
  qgctgan_generator(
    name = "ctgan",
    fit = function(X) {
      X <- as.matrix(X)
      ctgan <- reticulate::import("ctgan", delay_load = TRUE)
      pd <- reticulate::import("pandas", delay_load = TRUE)
      cols <- paste0("f", seq_len(ncol(X)) - 1L)
      df <- pd$DataFrame(data = as.data.frame(X),
                         columns = reticulate::r_to_py(cols))
      args <- c(list(epochs = as.integer(epochs), verbose = verbose), extra)
      model <- do.call(ctgan$CTGAN, args)
      model$fit(df)
      list(model = model, d = ncol(X))
    },
    sample = function(model, n) {
      if (n <= 0) return(matrix(numeric(0), 0, model$d))
      out <- model$model$sample(as.integer(n))
      as.matrix(reticulate::py_to_r(out))
    })
}
