#' Quality-aware cluster-conditioned oversampling
#'
#' Oversamples the minority class of an imbalanced binary problem. The minority
#' class is partitioned into sub-clusters with a Gaussian mixture model; a
#' generator is fitted per sub-cluster and used to draw synthetic candidates;
#' the candidates then pass the two-stage quality filter (Stage 1: composite
#' quality score \eqn{Q(x)} with an adaptive per-cluster rejection quantile;
#' Stage 2: greedy MMD selection) before the retained samples are added to the
#' training set.
#'
#' @param x A numeric matrix or data frame of (preferably standardised) numeric
#'   features, one observation per row.
#' @param y A vector of binary class labels, one per row of \code{x}.
#' @param positive The label of the minority/positive class. If \code{NULL}
#'   (default), the least frequent label is used.
#' @param generator A \code{\link{qgctgan_generator}}. Defaults to the pure-R
#'   \code{\link{generator_gaussian}}; use \code{\link{generator_ctgan}} to
#'   reproduce the GAN-based generation of the reference study.
#' @param target_ratio Desired minority fraction after oversampling.
#' @param k_range Integer vector of candidate GMM component counts (BIC-selected).
#' @param alpha_mode \code{"adaptive"} (per-cluster, from GMM log-likelihood) or
#'   \code{"fixed"}.
#' @param alpha Rejection quantile used when \code{alpha_mode = "fixed"}.
#' @param alpha_min,alpha_max Bounds for the adaptive rejection quantile.
#' @param mmd_stage Logical; run the Stage-2 MMD selection.
#' @param filter Logical; if \code{FALSE}, the two-stage filter is skipped and
#'   synthetic samples are drawn uniformly at random from the candidate pool
#'   (the unfiltered "G-CTGAN" baseline). See also \code{\link{gctgan}}.
#' @param candidate_multiplier,max_multiplier,safety_factor Control how many
#'   candidates are generated per minority sample.
#' @param weights Length-3 weights for the density, separability and
#'   local-outlier components of \eqn{Q(x)}.
#' @param n_neighbors Neighbour count for the local-outlier component.
#' @param seed Optional integer seed for reproducibility.
#' @param verbose Logical; print progress.
#'
#' @return An object of class \code{"qgctgan"}: a list with the rebalanced
#'   feature matrix \code{x}, labels \code{y}, the \code{synthetic} samples that
#'   were added, and an \code{info} list of diagnostics.
#'
#' @references Yang, M. (2026). Quality-Aware Cluster-Conditioned Oversampling
#'   via Intra-Cluster Synthetic Sample Filtering. \emph{Applied Soft
#'   Computing}.
#'
#' @examples
#' set.seed(1)
#' n <- 200
#' x <- rbind(matrix(rnorm(2 * n), n, 2),
#'            matrix(rnorm(2 * 20, mean = 2), 20, 2))
#' y <- c(rep(0L, n), rep(1L, 20))
#' res <- qgctgan(x, y, seed = 1)
#' table(res$y)
#'
#' @export
qgctgan <- function(x, y, positive = NULL,
                    generator = generator_gaussian(),
                    target_ratio = 0.5,
                    k_range = 2:10,
                    alpha_mode = c("adaptive", "fixed"),
                    alpha = 0.2,
                    alpha_min = 0.1, alpha_max = 0.3,
                    mmd_stage = TRUE,
                    filter = TRUE,
                    candidate_multiplier = 5,
                    max_multiplier = 50,
                    safety_factor = 1.5,
                    weights = c(1/3, 1/3, 1/3),
                    n_neighbors = 5L,
                    seed = NULL,
                    verbose = FALSE) {
  alpha_mode <- match.arg(alpha_mode)
  if (!inherits(generator, "qgctgan_generator")) {
    stop("'generator' must be a qgctgan_generator (see ?qgctgan_generator).",
         call. = FALSE)
  }
  x <- as.matrix(x)
  storage.mode(x) <- "double"
  cn <- colnames(x)
  if (length(y) != nrow(x)) stop("length(y) must equal nrow(x).", call. = FALSE)
  lv <- unique(y)
  if (length(lv) != 2L) stop("qgctgan() supports binary problems only.", call. = FALSE)

  if (is.null(positive)) {
    tab <- table(y)
    positive <- names(tab)[which.min(tab)]
    positive <- methods::as(positive, class(y))
  }
  if (!positive %in% lv) stop("'positive' is not a label of y.", call. = FALSE)
  negative <- setdiff(lv, positive)

  is_min <- y == positive
  X_min <- x[is_min, , drop = FALSE]
  X_maj <- x[!is_min, , drop = FALSE]
  n_min <- nrow(X_min); n_maj <- nrow(X_maj)

  if (!is.null(seed)) set.seed(seed)

  if (n_min < 2L) {
    warning("Fewer than two minority samples; returning data unchanged.",
            call. = FALSE)
    return(.qgctgan_result(x, y, matrix(numeric(0), 0, ncol(x)),
                           list(best_k = 0L, n_synthetic = 0L), cn))
  }

  ## 1. GMM sub-clustering of the minority class
  gmm <- fit_gmm_select(X_min, k_range = k_range, seed = seed)
  best_k <- gmm$best_k
  labels <- gmm$labels
  cluster_sizes <- as.integer(table(factor(labels, levels = seq_len(best_k) - 1L)))
  if (verbose) message(sprintf("GMM: best_k=%d  cluster_sizes=%s",
                               best_k, paste(cluster_sizes, collapse = ",")))

  ## 2. Candidate budget
  mult <- compute_required_multiplier(n_min, n_maj, target_ratio,
                                      candidate_multiplier, safety_factor,
                                      max_multiplier)

  ## 3. Per-cluster generator fit + candidate generation
  candidates <- vector("list", best_k)
  for (c in seq_len(best_k)) {
    X_c <- X_min[labels == (c - 1L), , drop = FALSE]
    n_gen <- max(round(nrow(X_c) * mult$multiplier), 10)
    candidates[[c]] <- if (nrow(X_c) < 2L) {
      matrix(numeric(0), 0, ncol(x))
    } else {
      tryCatch({
        model <- generator$fit(X_c)
        as.matrix(generator$sample(model, n_gen))
      }, error = function(e) {
        if (verbose) message(sprintf("  cluster %d: generator failed (%s)", c - 1L, conditionMessage(e)))
        matrix(numeric(0), 0, ncol(x))
      })
    }
  }
  n_cand_total <- sum(vapply(candidates, nrow, integer(1)))

  ## 4. Selection: two-stage filter, or unfiltered random draw
  if (filter) {
    alpha_vec <- if (alpha_mode == "adaptive") {
      compute_adaptive_alpha(gmm$loglik_point, labels, best_k, alpha_min, alpha_max)
    } else {
      rep(alpha, best_k)
    }
    fres <- filter_by_quality(candidates, X_min, labels, X_maj, gmm, best_k,
                              alpha_vec, target_ratio = target_ratio,
                              mmd_stage_enabled = mmd_stage, weights = weights)
    X_syn <- fres$X_syn
    quality_info <- fres$quality_info
  } else {
    alpha_vec <- NA_real_
    quality_info <- NULL
    X_syn <- .unfiltered_draw(candidates, n_min, n_maj, target_ratio, ncol(x))
  }

  ## 5. MMD diagnostics (before vs after filtering)
  all_cand <- Filter(function(m) nrow(m) > 0, candidates)
  all_cand <- if (length(all_cand)) do.call(rbind, all_cand) else matrix(numeric(0), 0, ncol(x))
  mmd_before <- if (nrow(all_cand) > 0) mmd_squared(X_min, all_cand) else NA_real_
  mmd_after <- if (nrow(X_syn) > 0) mmd_squared(X_min, X_syn) else NA_real_

  ## 6. Assemble rebalanced data (majority, real minority, synthetic minority)
  X_out <- rbind(X_maj, X_min, X_syn)
  colnames(X_out) <- cn
  y_out <- c(rep(negative, n_maj), rep(positive, n_min + nrow(X_syn)))
  if (is.factor(y)) y_out <- factor(y_out, levels = levels(y))

  info <- list(
    best_k = best_k,
    cluster_sizes = cluster_sizes,
    positive = positive,
    generator = generator$name,
    alpha_mode = alpha_mode,
    alpha_vec = round(alpha_vec, 3),
    filter = filter,
    mmd_stage = mmd_stage,
    n_candidates = n_cand_total,
    candidate_multiplier_used = round(mult$multiplier, 2),
    multiplier_capped = mult$multiplier >= max_multiplier,
    n_syn_target = mult$n_syn_needed,
    n_synthetic = nrow(X_syn),
    minority_ratio = round(sum(y_out == positive) / length(y_out), 4),
    mmd_before = if (is.na(mmd_before)) NA_real_ else round(mmd_before, 6),
    mmd_after = if (is.na(mmd_after)) NA_real_ else round(mmd_after, 6),
    quality_info = quality_info)

  .qgctgan_result(X_out, y_out, X_syn, info, cn)
}

#' Unfiltered cluster-conditioned oversampling (G-CTGAN baseline)
#'
#' Convenience wrapper for \code{qgctgan(..., filter = FALSE)}: the same
#' generative base (GMM + per-cluster generator + candidate pool) with the
#' two-stage quality filter removed, so synthetic samples are drawn uniformly at
#' random from the candidate pool. Used to isolate the contribution of the
#' filter.
#'
#' @inheritParams qgctgan
#' @return An object of class \code{"qgctgan"}.
#' @export
gctgan <- function(x, y, positive = NULL, generator = generator_gaussian(),
                   target_ratio = 0.5, k_range = 2:10,
                   candidate_multiplier = 5, max_multiplier = 50,
                   safety_factor = 1.5, seed = NULL, verbose = FALSE) {
  qgctgan(x, y, positive = positive, generator = generator,
          target_ratio = target_ratio, k_range = k_range, filter = FALSE,
          candidate_multiplier = candidate_multiplier,
          max_multiplier = max_multiplier, safety_factor = safety_factor,
          seed = seed, verbose = verbose)
}

## Uniform random draw from the candidate pool (no filtering).
.unfiltered_draw <- function(candidates, n_min, n_maj, target_ratio, d) {
  n_syn_needed <- max(round((target_ratio * (n_maj + n_min) - n_min) /
                              (1 - target_ratio)), 0)
  pool <- Filter(function(m) nrow(m) > 0, candidates)
  if (length(pool) == 0) return(matrix(numeric(0), 0, d))
  X_pool <- do.call(rbind, pool)
  if (nrow(X_pool) <= n_syn_needed) return(X_pool)
  X_pool[sample.int(nrow(X_pool), n_syn_needed), , drop = FALSE]
}

.qgctgan_result <- function(x, y, synthetic, info, cn) {
  if (!is.null(cn)) colnames(x) <- cn
  structure(list(x = x, y = y, synthetic = synthetic, info = info),
            class = "qgctgan")
}

#' @export
print.qgctgan <- function(x, ...) {
  i <- x$info
  cat("<qgctgan oversampling result>\n")
  cat(sprintf("  rebalanced: %d rows (%d features)\n", nrow(x$x), ncol(x$x)))
  if (!is.null(i$best_k)) cat(sprintf("  minority clusters (best_k): %d\n", i$best_k))
  if (!is.null(i$n_synthetic)) cat(sprintf("  synthetic samples added: %d\n", i$n_synthetic))
  if (!is.null(i$minority_ratio)) cat(sprintf("  minority ratio: %.3f\n", i$minority_ratio))
  if (!is.null(i$generator)) cat(sprintf("  generator: %s | filter: %s\n",
                                         i$generator, isTRUE(i$filter)))
  if (!is.null(i$mmd_before) && !is.na(i$mmd_before))
    cat(sprintf("  MMD^2 before=%.6f after=%.6f\n", i$mmd_before, i$mmd_after))
  invisible(x)
}
