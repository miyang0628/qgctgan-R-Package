## Two-stage quality filter.
## Ported from qgctgan_core.py (filter_by_quality).

#' Two-stage quality filter
#'
#' Stage 1 rejects, within each cluster, the lower \eqn{\alpha_c} quantile of the
#' composite quality score \eqn{Q(x)}. Stage 2 greedily keeps the candidates
#' whose MMD contribution best aligns the retained set with the real minority.
#'
#' @param candidates List of length \code{best_k}; element \code{c} is a numeric
#'   matrix of candidate samples for cluster \code{c-1}.
#' @param X_min,X_maj Numeric matrices of real minority/majority observations.
#' @param labels 0-based cluster assignments for the rows of \code{X_min}.
#' @param gmm A fitted GMM list (see \code{\link{fit_gmm_select}}).
#' @param best_k Number of clusters.
#' @param alpha_vec Numeric vector of per-cluster rejection quantiles.
#' @param target_ratio Target minority fraction.
#' @param mmd_stage_enabled Whether to run the Stage-2 MMD selection.
#' @param weights Length-3 quality-score weights.
#' @return A list with \code{X_syn} (numeric matrix of selected synthetic
#'   samples) and \code{quality_info} (per-cluster diagnostics).
#' @keywords internal
filter_by_quality <- function(candidates, X_min, labels, X_maj, gmm, best_k,
                              alpha_vec, target_ratio = 0.5,
                              mmd_stage_enabled = TRUE,
                              weights = c(1/3, 1/3, 1/3)) {
  d <- ncol(X_min)
  n_maj <- nrow(X_maj); n_min <- nrow(X_min)
  n_syn_needed <- max(round((target_ratio * (n_maj + n_min) - n_min) /
                              (1 - target_ratio)), 0)

  mu_minority_all <- gmm$means
  mu_majority_clusters <- matrix(colMeans(X_maj), nrow = 1)

  filtered <- vector("list", best_k)
  quality_info <- vector("list", best_k)

  for (c in seq_len(best_k)) {
    X_cand <- candidates[[c]]
    X_c <- X_min[labels == (c - 1L), , drop = FALSE]

    if (nrow(X_cand) == 0 || nrow(X_c) < 2) {
      filtered[[c]] <- matrix(numeric(0), 0, d)
      quality_info[[c]] <- list(n_candidate = 0L, n_after_filter = 0L,
                                alpha = alpha_vec[c], mean_Q_before = NA_real_,
                                mean_Q_after = NA_real_)
      next
    }

    Q <- quality_score(X_cand, gmm$means[c, ], gmm$covariances[, , c],
                       mu_minority_all, mu_majority_clusters, X_c, w = weights)
    alpha_c <- alpha_vec[c]
    threshold <- stats::quantile(Q, alpha_c, names = FALSE)
    mask <- Q >= threshold
    filtered[[c]] <- X_cand[mask, , drop = FALSE]
    quality_info[[c]] <- list(
      n_candidate = nrow(X_cand),
      n_after_filter = sum(mask),
      alpha = round(alpha_c, 3),
      mean_Q_before = round(mean(Q), 4),
      mean_Q_after = if (any(mask)) round(mean(Q[mask]), 4) else NA_real_)
  }

  pool_list <- Filter(function(m) nrow(m) > 0, filtered)
  if (length(pool_list) == 0) {
    return(list(X_syn = matrix(numeric(0), 0, d), quality_info = quality_info))
  }
  X_pool <- do.call(rbind, pool_list)

  if (!mmd_stage_enabled) {
    X_final <- if (nrow(X_pool) > n_syn_needed) X_pool[seq_len(n_syn_needed), , drop = FALSE] else X_pool
    return(list(X_syn = X_final, quality_info = quality_info))
  }
  if (nrow(X_pool) <= n_syn_needed) {
    return(list(X_syn = X_pool, quality_info = quality_info))
  }

  gamma <- median_bandwidth(X_min, X_pool)
  mmd_scores <- vapply(seq_len(nrow(X_pool)),
                       function(i) mmd_contribution(X_pool[i, ], X_min, X_pool, gamma),
                       numeric(1))
  top_idx <- order(mmd_scores)[seq_len(n_syn_needed)]
  list(X_syn = X_pool[top_idx, , drop = FALSE], quality_info = quality_info)
}
