make_imbalanced <- function(seed = 42, n_maj = 200, n_min = 30, d = 4) {
  set.seed(seed)
  X_maj <- matrix(rnorm(n_maj * d), n_maj, d)
  X_min <- rbind(matrix(rnorm((n_min %/% 2) * d, mean = 2.5), n_min %/% 2, d),
                 matrix(rnorm((n_min - n_min %/% 2) * d, mean = -2.5),
                        n_min - n_min %/% 2, d))
  list(x = rbind(X_maj, X_min),
       y = c(rep(0L, n_maj), rep(1L, n_min)))
}

test_that("rbf_kernel and mmd behave sensibly", {
  set.seed(1)
  X <- matrix(rnorm(40), 20, 2)
  K <- qgctgan:::rbf_kernel(X, X)
  expect_equal(dim(K), c(20L, 20L))
  expect_true(all(diag(K) == 1))                 # self-similarity = 1
  expect_lt(abs(qgctgan:::mmd_squared(X, X)), 1e-8)  # MMD of a set with itself ~ 0
})

test_that("adaptive alpha is within bounds and length best_k", {
  set.seed(2)
  a <- qgctgan:::compute_adaptive_alpha(rnorm(20), rep(0:1, each = 10), 2L,
                                        alpha_min = 0.1, alpha_max = 0.3)
  expect_length(a, 2L)
  expect_true(all(a >= 0.1 & a <= 0.3))
})

test_that("qgctgan rebalances to the target ratio", {
  d <- make_imbalanced()
  res <- qgctgan(d$x, d$y, seed = 42)
  expect_s3_class(res, "qgctgan")
  expect_equal(unname(table(res$y)["1"]), unname(table(res$y)["0"]))
  expect_gt(res$info$n_synthetic, 0)
  expect_true(res$info$best_k >= 1)
  expect_equal(ncol(res$x), ncol(d$x))
})

test_that("fixed alpha and mmd-off paths run", {
  d <- make_imbalanced()
  res <- qgctgan(d$x, d$y, alpha_mode = "fixed", alpha = 0.2,
                 mmd_stage = FALSE, seed = 42)
  expect_s3_class(res, "qgctgan")
  expect_false(res$info$mmd_stage)
})

test_that("unfiltered gctgan baseline runs", {
  d <- make_imbalanced()
  res <- gctgan(d$x, d$y, seed = 42)
  expect_false(res$info$filter)
  expect_gt(res$info$n_synthetic, 0)
})

test_that("custom generator is accepted", {
  d <- make_imbalanced()
  gen <- qgctgan_generator(
    fit = function(X) list(mu = colMeans(X), d = ncol(X)),
    sample = function(m, n) matrix(m$mu, n, m$d, byrow = TRUE),
    name = "mean")
  res <- qgctgan(d$x, d$y, generator = gen, seed = 1)
  expect_equal(res$info$generator, "mean")
})

test_that("factor labels are preserved", {
  d <- make_imbalanced()
  yf <- factor(ifelse(d$y == 1, "pos", "neg"))
  res <- qgctgan(d$x, yf, positive = "pos", seed = 42)
  expect_true(is.factor(res$y))
  expect_setequal(levels(res$y), c("neg", "pos"))
})

test_that("too few minority samples returns data unchanged with a warning", {
  set.seed(5)
  x <- matrix(rnorm(100 * 3), 100, 3)
  y <- c(rep(0L, 99), 1L)
  expect_warning(res <- qgctgan(x, y), "minority")
  expect_equal(nrow(res$x), 100L)
})

test_that("non-binary input is rejected", {
  x <- matrix(rnorm(30), 10, 3)
  expect_error(qgctgan(x, rep(1:3, length.out = 10)), "binary")
})
