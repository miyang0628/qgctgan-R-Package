library(testthat)
library(qgctgan)

test_check("qgctgan")
